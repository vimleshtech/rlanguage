
setwd("C:\\Users\\vkumar15\\Desktop\\backup\\")

library(xlsx)

library(class)

read.csv("bmi.csv")
read.xlsx("Health data.xlsx",sheetIndex = 1)
data = read.csv("C:\\Users\\vkumar15\\Downloads\\cancer data.csv")

write.csv(data,"C:\\Users\\vkumar15\\Downloads\\output.csv")

str(data)
head(data)

normalize <- function(x) {
  #x < as.list(x)
  d =((x - min(x)) / (max(x) - min(x))) 
  
  print(d)
  return (d)
  }



prc_n <- as.data.frame(lapply(data[3:5],normalize))


prc_train <- prc_n[1:65,]
prc_test <- prc_n[66:100,]



prc_train_labels <- data[1:65, 1]
prc_test_labels <- data[66:100, 1]   #This code takes the diagnosis factor in column 1 

prc_test_pred <- knn(train = prc_train, test = prc_test,cl = prc_train_labels, k=10)


summary(prc_test_pred)


write.csv(prc_test_pred,"C:\\Users\\vkumar15\\Downloads\\output1.csv")

  