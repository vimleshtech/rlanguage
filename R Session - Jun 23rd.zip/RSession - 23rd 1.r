## select the code then press ctrl + enter 
# is single comment 

a = 1  # here a is variable and  1 is value or data 
#OR 
a <- 1  # 





a = 100
typeof(a)
a =1.22
typeof(a)




#####
a =13

# if condition 
if(a%%2 == 0){
  
    print('even no')
}

## if else 
if(a%%2 == 0){
  
  print('even no')
} else {
  print('ODD no')
}


####
a =100
b =4
c =44
if (a > b & a>c){
  
  print('a is gt')
  
}else if(b>a & b>c){
  
  print(' b is gt')
  
}else{
  
  print('c is gt')
  
}




#### while loop 
i =1 # init 
while(i<=100) { # condition 

  print(i)
  i =i+1 # increment  
}


## print in reverse 
i =100
while(i>0){
  
  print(i)
  i =i-1
}

## print table of 4 
i =1
while(i<=10){
  
  print(i*4)
  i =i+1
}



## break example
i =1
while(i <=10){
  
  
  if(i %%  3 == 0){
    break
  }
  print(i)
  i=i+1
}

##
## next example
v1 <- c(1:10)

for(x in v1){   #  HERE X IS NEW VARIABLE WHICH WILL TAKE VALUE FROM V1 BY INDEX /
  
  if(x %% 4 == 0)
  {
    next
  }
  print(x)
}



####
i =1
repeat{
  
  
  print(i)
  i=i+1
  
  if( i == 10){
    break
  }
  
}



######
#no argument , no return 
wel <- function(){
  
    print('welcome to function world')
}


## no argument with return 
getNum <- function(){
  
  a =1111
  return (a)
}

### argument with no return
add <- function(a,b){
  
  c =a+b
  print(c)
}

### argument with return
sub <- function(a,b){
  
  c =a-b
  return(c)
}

wel()