add(11,2)

add(1111222,sub(333,4))

### swtich 

switch(3,'mon','tue','wed','thu','fri')

### string handling 

fn = "nitin"
ln ="sinha"

name = fn+ln

paste(fn,ln)

paste(fn,ln,sep = ',')


paste(fn,"kumar",ln,sep = ',')


#####vector : is collection of data or values 
w <- c("one","two","three")

w[1]
w[2]
w[3]
w[1:2]


## wap to show factorial of given no.
n =5

## wap to convert digit to word
# 123 : one hundred twenty three 

i=1
n=5
while(n>=1){
  
  i=i*n
  n=n-1
  
}
print(i)

n=123
n1=n%/%100
n=n%%100

n2=n%/%10
n=n%%10
n3=n%/%1

