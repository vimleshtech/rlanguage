
import pandas
from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt


url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pandas.read_csv(url, names=cols)
print(dataset)


#write to csv
#dataset.to_csv(r"C:\Users\vkumar15\Desktop\PAF\out.csv",index=False)
# r code: read.csv("path")

##group by 
print(dataset.groupby('class').size())


##show stats 
print(dataset.describe())

d =dataset.describe()
#d.to_csv(r"C:\Users\vkumar15\Desktop\PAF\out1.csv")

print(dataset.drop(['sepal-length'],axis=1).describe())

#nd = data.frame(old$col1,old$col2)


#scatter 
#scatter_matrix(dataset)
#plt.show()

#dataset.hist()
#plt.show()

#dataset.plot(kind='line', subplots=True, layout=(2,2), sharex=False, sharey=False)
#dataset.plot(kind='line', subplots=False)
dataset.plot(kind='box', subplots=False)
plt.show()










