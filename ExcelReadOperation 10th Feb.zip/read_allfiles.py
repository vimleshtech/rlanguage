import os
import shutil
import xlrd

def read_files(path):
     o = os.listdir(path)
     for f in o:  #for (x in o){        
          if f.endswith(".xlsx")  or f.endswith(".xls"):  #if (f.endsWith(".xlsx") ||   )   {                       
               #print(f)
               shutil.copy(path+'\\'+f,r"C:\Users\vkumar15\Documents\Sandbox\out")
               #shutil.move(from,to)
               #shutil.delete(file)
               loc = path+'\\'+f
               wb = xlrd.open_workbook(loc)
               sh = wb.sheet_by_index(0)
               nr = sh.nrows
               nc = sh.ncols
               #read all columns(header)
               for x in range(0,nc):
                    print(sh.cell_value(0,x),end=',')


     #print(len(o))



'''
setwd("C:\\Users\\vkumar15\\Documents\\Sandbox\\Excel")

readfiles(getwd())
o = readfiles("C:\\Users\\vkumar15\\Documents\\Sandbox\\Excel")
length(o)


'''

#
loc = r"C:\Users\vkumar15\Documents\Sandbox\Excel"
read_files(loc)



     
     
     
