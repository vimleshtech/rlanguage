import xlrd
'''
workbook
select_sheet_by_index
select_sheet_by_name
nrows
ncols

'''

loc = r"C:\Users\vkumar15\Documents\Sandbox\Excel\Sample - Superstore - Copy.xlsx"
wb = xlrd.open_workbook(loc)
sh = wb.sheet_by_index(0)

nr = sh.nrows
nc = sh.ncols
print(nr)
print(nc)

#read one cell value 
d = sh.cell_value(0,0)
print(d)

#read all columns(header)
for x in range(0,nc):
     print(sh.cell_value(0,x),end=',')

#read all rows of given column
for x in range(0,nr):
     print(sh.cell_value(x,20))

#read all data
for x in range(0,nr):
     for c in range(0,nc):
          print(sh.cell_value(x,c),end=',')
     print()


'''
sh

rc = length(sh$profit)
cc = length(sh) 

i = 1
while(i<=rc){

     c =1
     while(c<=cc){

          print(sh[i,c])
          c =c+1
     }

     i =i+1
}


'''
     

     


     

     
     
     






















