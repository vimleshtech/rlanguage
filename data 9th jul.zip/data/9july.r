fn <- "raman"
ln <- "sinha"

paste(fn,ln)

###
setwd("C:\\Users\\Tech Vision\\Desktop\\data")

sentences1<-scan("data1.txt","character",sep="\n")
sentences2<-scan("data2.txt","character",sep="\n");

sentence<- paste(sentences1,sentences2)

#remove the special characters 
#$, @ - / . ,
sp<- c("$","@","-","\\.","\\,")
for ( x in sp){

sentence<-gsub(x,"",sentence)
}

#sentence<-gsub("\\,","",sentence)

#break string /sentence by seperator
words <- strsplit(sentence," ")

#get word freq 
freq <- table( unlist(words))


barplot(freq,col="red")
pie(freq,col="red")

#######

install.packages("twitteR")
install.packages("devtools")
install.packages("SnowballC")
install.packages("tm")
install.packages("syuzhet")

library("devtools")
library("SnowballC")

library("tm")
library("twitteR")
library("syuzhet")

yZ9dF68F4wgfnaMN97H8VFceC
TBEGDj7AqIkO9KIbKdBy1h1ITg0YcOksYf2X4Brgbx081PHLQ5
IHIaaNkrP3CDCcgysJNIu45IbfDQ7Kc8XyfsQUiN
T0EeJZKqM8d0Dg1Y6M1KKSokV9vTau47oPEdXK2VEWK2j

consumer_key <- 'yZ9dF68F4wgfnaMN97H8VFceC'
consumer_secret <-'TBEGDj7AqIkO9KIbKdBy1h1ITg0YcOksYf2X4Brgbx081PHLQ5'
access_token <- '265838776-IHIaaNkrP3CDCcgysJNIu45IbfDQ7Kc8XyfsQUiN'
access_secret <- 'T0EeJZKqM8d0Dg1Y6M1KKSokV9vTau47oPEdXK2VEWK2j'

setup_twitter_oauth(consumer_key, consumer_secret, access_token, access_secret)

tweetdt <- userTimeline("realDonaldTrump", n=100)
 

tweets.df <- twListToDF(tweetdt)

write.csv(tweets.dfu,"out.csv")

#read text from dataframe 
tweets.df2 <- gsub("http.*","",tweets.df$text)
tweets.df2 <- gsub("#.*","",tweets.df2)

tweets.df2 <- gsub("@.*","",tweets.df2)
word.df <- as.vector(tweets.df2)

data<- read.csv("out.csv")
tdata1<-data$text
sentences1<-scan("data1"","character",sep="\n")

